import '../sass/theme.scss'
import * as bootstrap from 'bootstrap'
import '/node_modules/bootstrap-icons/font/bootstrap-icons.scss';
import VenoBox from "venobox";

new VenoBox({
    selector: ".venobox"
});