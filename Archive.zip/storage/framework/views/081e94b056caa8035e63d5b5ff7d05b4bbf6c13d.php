<?php $__env->startSection('content'); ?>
    <nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='%236c757d'/%3E%3C/svg%3E&#34;);"
         aria-label="breadcrumb">
        <ol class="breadcrumb mb-1">
            <li class="breadcrumb-item"><a class="text-decoration-none text-black-50 text-uppercase"
                                           href="<?php echo e(route('home')); ?>">Home</a></li>
            <li class="breadcrumb-item"><a class="text-decoration-none text-black-50 text-uppercase"
                                           href="<?php echo e(route('post.index')); ?>">POst</a></li>
            <li class="breadcrumb-item text-uppercase active" aria-current="page">POst Detail</li>
        </ol>
    </nav>
    <div class="card">
        <div class="card-body">
            <h4><?php echo e($post->title); ?></h4>
            <div class="">
                <span class="badge bg-dark">
                    <i class="bi bi-person-circle"></i>
                    <?php echo e($post->user->name); ?>

                </span>
                <span class="badge bg-dark">
                    <i class="bi bi-tag"></i>
                    <?php echo e($post->category->title); ?>

                </span>
                <span class="badge bg-dark">
                        <i class="bi bi-calendar"></i>
                        <?php echo e($post->created_at->format('d M Y')); ?>

                </span>
                <span class="badge bg-dark">
<i class="bi bi-clock"></i>
                                <?php echo e($post->created_at->format("h : m A")); ?>

                </span>
            </div>
            <hr>
            <div class="mb-3 text-center">
                <?php if(isset($post->featured_image)): ?>
                    <img src="<?php echo e(asset('storage/'.$post->featured_image)); ?>" class="w-50 mt-3 rounded" alt="">
                <?php endif; ?>
            </div>
            <p>
                <?php echo e($post->description); ?>

            </p>
            <div class="mb-3  d-flex">
                <?php $__currentLoopData = $post->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="me-3">
                        <img src="<?php echo e(asset('storage/'.$photo->name)); ?>" height="200" class="rounded text-center" alt="">
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <hr>
            <div class="d-flex justify-content-between">
                <a class="btn btn-outline-primary" href="<?php echo e(route('post.index',$post->id)); ?>">
                  All Post
                </a>
                <a class="btn btn-primary" href="<?php echo e(route('post.create')); ?>">
                    Create Post
                </a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bominsoe/Desktop/Blog/resources/views/post/show.blade.php ENDPATH**/ ?>