<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-6 col-md-4 col-lg-8">
                <h1 class="text-uppercase text-center">Blog Post</h1>
                <div class="d-flex justify-content-between mb-3">
                    <div class="">
                        <?php if(isset($category)): ?>
                            <div class="">
                                <span class="">Filter By : ' <?php echo e($category->title); ?> '</span>
                                <a href="<?php echo e(route('page.index')); ?>"><i class="bi bi-x-circle-fill"></i></a>
                            </div>
                        <?php endif; ?>
                        <?php if(request('keyword')): ?>
                            <span class="">Search By : ' <?php echo e(request('keyword')); ?> '</span>
                            <a href="<?php echo e(route('page.index')); ?>"><i class="bi bi-x-circle-fill"></i></a>
                        <?php endif; ?>
                    </div>
                    <form method="get" action="<?php echo e(route('page.index')); ?>">
                        <div class="input-group">
                            <input class="form-control" placeholder="search anything" type="text" name="keyword">
                            <button class="btn btn-outline-primary"><i class="bi bi-search"></i> Search</button>
                        </div>
                    </form>

                </div>
                <div class="">

                </div>
                <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="card mb-3">
                    <div class="card-body p-3">
                        <div class="">
                            <h3 class="text-decoration-none card-title text-primary">
                                <?php echo e($post->title); ?>

                            </h3>
                        </div>
                        <div class="pb-2">
                            <span class="badge bg-secondary">
                                <i class="bi bi-person-circle"></i>
                                <?php echo e($post->user->name); ?>

                            </span>
                            <a href="<?php echo e(route('page.cat',$post->category->slug)); ?>">
                            <span class="badge bg-secondary">
                                <i class="bi bi-tag"></i>
                                <?php echo e($post->category->title); ?>

                            </span>
                            </a>
                        </div>
                        <div class="">
                            <p class="text-black-50">
                                <?php echo e($post->excerpt); ?>

                            </p>
                        </div>
                        <div class="d-flex justify-content-between">
                            <div class="">
                                <?php echo e($post->created_at->diffforHumans()); ?>

                            </div>
                            <div class="">
                                <a class="btn btn-sm btn-outline-primary" href="<?php echo e(route('page',$post->slug)); ?>">Seemore</a>
                            </div>
                        </div>
                     
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
                <?php echo e($posts->onEachSide(1)->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bominsoe/Desktop/Blog/resources/views/index.blade.php ENDPATH**/ ?>