<?php $__env->startSection('content'); ?>
    <nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='%236c757d'/%3E%3C/svg%3E&#34;);" aria-label="breadcrumb">
        <ol class="breadcrumb mb-1">
            <li class="breadcrumb-item"><a class="text-decoration-none text-black-50 text-uppercase" href="<?php echo e(route('home')); ?>">Home</a></li>
            <li class="breadcrumb-item active text-uppercase" aria-current="page">Category</li>
        </ol>
    </nav>
    <div class="card">
        <div class="card-body">
            <h4>Manage Category</h4>
           <table class="table table-bordered table-hover">
               <thead>
                <tr>
                    <th>#</th>
                    <th>Title</th>
                    <th>Post Count</th>
                    <th>Control</th>
                    <th>Created</th>
                </tr>
               </thead>
               <tbody>
               <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                   <td><?php echo e($category->id); ?></td>
                   <td><?php echo e($category->title); ?>

                       <br>
                       <?php if (\Illuminate\Support\Facades\Blade::check('notAuthor')): ?>
                       <kbd class="badge bg-primary">
                            <?php echo e($category->user->name); ?>

                        </kbd>
                       <?php endif; ?>
                   <span class="badge bg-warning">
                       <?php echo e($category->slug); ?>

                   </span>
                   </td>
                    <th><?php echo e($category->posts()->count()); ?></th>
                    <td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update',$category)): ?>
                        <a class="btn btn-outline-warning" href="<?php echo e(route('category.edit',$category->id)); ?>">
                            <i class="bi bi-pen-fill"></i>
                        </a>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete',$category)): ?>
                        <form method="post" class="d-inline-block" action="<?php echo e(route('category.destroy',$category->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button class="btn btn-outline-danger">
                                <i class="bi bi-trash2"></i>
                            </button>
                        </form>
                            <?php endif; ?>
                    </td>
                    <td>
                        <p class="small ">
                            <i class="bi bi-calendar"></i>
                            <?php echo e($category->created_at->format('d M Y')); ?>

                        </p>
                        <p class="small mb-0 text-black-50">
                            <i class="bi bi-clock"></i>
                            <?php echo e($category->created_at->format("h : m A")); ?>

                        </p>
                    </td>
               </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

               <?php endif; ?>

               </tbody>
           </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bominsoe/Desktop/Blog/resources/views/category/index.blade.php ENDPATH**/ ?>