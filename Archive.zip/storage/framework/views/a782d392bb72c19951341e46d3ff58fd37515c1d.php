
<div class="list-group mb-3">
    <a class="list-group-item list-group-item-action
            " href="<?php echo e(route('home')); ?>">
        Home
    </a>
    <a class="list-group-item list-group-item-action" href="<?php echo e(route('test')); ?>">
        Test
    </a>
    <a class="list-group-item list-group-item-action" href="<?php echo e(route('photo.index')); ?>">
        Photo
    </a>
</div>
<p class="small text-black-50">Manage Post</p>
<div class="list-group mb-3">
    <a class="list-group-item list-group-item-action" href="<?php echo e(route('post.index')); ?>">
        Post list
    </a>
    <a class="list-group-item list-group-item-action" href="<?php echo e(route('post.create')); ?>">
        Create Post
    </a>
</div>
<p class="small text-black-50">Manage Category</p>

<div class="list-group mb-3">
    <a class="list-group-item list-group-item-action" href="<?php echo e(route('category.index')); ?>">
    Category List
    </a>
    <a class="list-group-item list-group-item-action" href="<?php echo e(route('category.create')); ?>">
        Create Category
    </a>
</div>

<?php if (\Illuminate\Support\Facades\Blade::check('Admin')): ?>
<p class="small text-black-50">Manage User</p>
<div class="list-group mb-3">
    <a class="list-group-item list-group-item-action" href="<?php echo e(route('users.index')); ?>">
        User List
    </a>
</div>
    <?php endif; ?><?php /**PATH /Users/bominsoe/Desktop/Blog/resources/views/layouts/sidebar.blade.php ENDPATH**/ ?>