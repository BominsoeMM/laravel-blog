<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-8">
                <h1 class="text-uppercase text-center">Blog Post</h1>
                <div class="card mb-3">
                    <div class="p-3">
                        <div class="">
                            <h3 class="text-decoration-none card-title text-primary">
                                <?php echo e($post->title); ?>

                            </h3>
                        </div>
                        <div class="pb-2">
                            <span class="badge bg-secondary">
                                <i class="bi bi-person-circle"></i>
                                <?php echo e($post->user->name); ?>

                            </span>
                            <span class="badge bg-secondary">
                                <i class="bi bi-tag"></i>
                                <?php echo e($post->category->title); ?>

                            </span>
                        </div>
                        <div class="">
                            <p style="white-space: pre-wrap" class="text-black-50">
                                <?php echo e($post->description); ?>

                            </p>
                        </div>
                        <div class="mb-3  d-flex justify-content-between">
                                <div class="">
                                    <?php echo e($post->created_at->diffforHumans()); ?>

                                </div>
                                <div class="">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update',$post)): ?>
                                        <a class="btn btn-sm btn-info" href="<?php echo e(route('post.edit',$post->id)); ?>">
                                            <i class="bi bi-pen-fill"></i>
                                        </a>
                                    <?php endif; ?>
                                    <a class="btn btn-sm btn-info" href="<?php echo e(route('page.index')); ?>">Back</a>

                                </div>
                        </div>



                    </div>
                    <div class="text-center my-3">
                        <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
                            <div class="carousel-inner ">
                                <?php $__currentLoopData = $post->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="me-3">
                                        <div class="text-center carousel-item  <?php echo e($key===0 ? 'active' : ''); ?>">
                                            <a class="venobox " data-gall="myGallery" href="<?php echo e(asset('storage/'.$photo->name)); ?>">
                                                <img src="<?php echo e(asset('storage/'.$photo->name)); ?>" class="d-block post-detail-img w-100">
                                            </a>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <button class="btn text-info carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
                                <i class="text-secondary bi bi-caret-left-fill"></i>
                            </button>
                            <button class="btn text-info carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
                                <i class="text-secondary bi bi-caret-right-fill"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bominsoe/Desktop/Blog/resources/views/page.blade.php ENDPATH**/ ?>